### 分销二维码 :   pages/fx_qrcode/index

### 使用接口

    获取我的分销二维码  ( /get_qrcode.html )

### 链接地址

     获取我的分销二维码 https://mini.sansancloud.com/chainalliance/xianhua/get_qrcode.html

##  获取我的分销二维码  ( /get_qrcode.html )
###  /get_qrcode.html  请求参数

|名称|说明|是否必要|备注
|:---:|:---:|:---:|:---:|
|jsonOnly|返回json|是|-

### /get_qrcode.html   返回字段说明

|名称|说明|备注
|:---:|:---:|:---:|
|errcode|返回码|-
|relateObj|二维码|-

### /get_qrcode.html  请求结果:

    {
      "errcode": "0",
      "errMsg": "success",
      "relateObj": "http://image1.sansancloud.com/xianhua/mini_qrcode_65595.jpg"
    }